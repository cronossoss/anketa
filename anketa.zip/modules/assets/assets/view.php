<?php

$pageTitle = "Pregled inventara";

$currentPage = 'asset-items';

include "../../../layouts/layout_start.php";

require_login();

require_role(['admin', 'it']);

$id = (int) ($_GET['id'] ?? 0);

if (!$id) {
    die('Neispravan ID.');
}

$stmt = $conn->prepare("
    SELECT
        a.*,

        t.name AS type_name,

        c.name AS category_name

    FROM assets a

    LEFT JOIN asset_types t
        ON t.id = a.asset_type_id

    LEFT JOIN asset_categories c
        ON c.id = a.category_id

    WHERE a.id = ?
");

$stmt->bind_param(
    "i",
    $id
);

$stmt->execute();

$asset =
    $stmt
    ->get_result()
    ->fetch_assoc();

if (!$asset) {
    die('Asset nije pronađen.');
}

/* =========================
   CURRENT ASSIGNMENT
========================= */

$assignmentStmt = $conn->prepare("
    SELECT
        aa.assigned_at,

        e.id AS employee_id,
        e.first_name,
        e.last_name,
        e.personal_id,

        ou.name AS unit_name

    FROM asset_assignments aa

    LEFT JOIN employees e
        ON e.id = aa.employee_id

    LEFT JOIN organizational_units ou
        ON ou.id = e.organizational_unit_id

    WHERE aa.asset_id = ?
    AND aa.returned_at IS NULL

    LIMIT 1
");

$assignmentStmt->bind_param(
    "i",
    $id
);

$assignmentStmt->execute();

$currentAssignment =
    $assignmentStmt
    ->get_result()
    ->fetch_assoc();

/* =========================
   DYNAMIC ATTRIBUTES
========================= */

$attributesStmt = $conn->prepare("
    SELECT
        d.name,
        d.code,
        d.field_type,

        v.value_text

    FROM asset_attribute_values v

    LEFT JOIN asset_attribute_definitions d
        ON d.id = v.attribute_definition_id

    WHERE v.asset_id = ?

    ORDER BY d.sort_order, d.name
");

$attributesStmt->bind_param(
    "i",
    $id
);

$attributesStmt->execute();

$attributes =
    $attributesStmt
    ->get_result();
?>

<main class="main-content">

    <!-- PAGE HEADER -->

    <div class="page-header mb-4">

        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">

            <div>

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <h1 class="mb-0">

                        <?= e($asset['name']) ?>

                    </h1>

                    <?php
                    $statusClass = match ($asset['status']) {

                        'assigned' => 'success',

                        'repair' => 'danger',

                        'reserve' => 'warning',

                        default => 'secondary'
                    };
                    ?>

                    <span class="badge bg-<?= $statusClass ?>">

                        <?= e(ucfirst($asset['status'])) ?>

                    </span>

                </div>

                <div class="text-muted mt-1">

                    Inventarski broj:
                    <strong>

                        <?= e($asset['inventory_number']) ?>

                    </strong>

                </div>

                

            </div>

            <div class="d-flex gap-2">

                <button
                    class="btn btn-primary btn-sm"
                    data-bs-toggle="modal"
                    data-bs-target="#assetEditModal">

                    <i class="fa-solid fa-pen me-1"></i>

                    Izmeni

                </button>

                <?php if ($currentAssignment): ?>

                    <button
                        type="button"
                        class="btn btn-warning btn-sm"

                        data-bs-toggle="modal"
                        data-bs-target="#changeAssignmentModal">

                        <i class="fa-solid fa-user-gear me-1"></i>

                        Promeni zaduženje

                    </button>

                    <form
                        method="POST"
                        action="../actions/unassign_asset.php"
                        onsubmit="return confirm('Razdužiti inventar?');">

                        <input
                            type="hidden"
                            name="asset_id"
                            value="<?= $asset['id'] ?>">

                        <button
                            type="submit"
                            class="btn btn-danger btn-sm">

                            <i class="fa-solid fa-user-minus me-1"></i>

                            Razduži

                        </button>

                    </form>



                <?php else: ?>

                    <button class="btn btn-success btn-sm">

                        <i class="fa-solid fa-user-plus me-1"></i>

                        Zaduži

                    </button>

                <?php endif; ?>

            </div>

        </div>

    </div>

    <!-- GRID -->

    <div class="row g-4">

        <!-- LEFT -->

        <div class="col-lg-8">

            <!-- OSNOVNI PODACI -->

            <div class="card shadow-sm border-0 mb-4">

                <div class="card-header">

                    <h5 class="mb-0">

                        Osnovni podaci

                    </h5>

                </div>

                <div class="card-body">

                    <table class="table align-middle mb-0">

                        <tr>

                            <th width="240">

                                Inventarski broj

                            </th>

                            <td>

                                <?= e($asset['inventory_number']) ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Tip

                            </th>

                            <td>

                                <?= e($asset['type_name']) ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Kategorija

                            </th>

                            <td>

                                <?= e($asset['category_name']) ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Status

                            </th>

                            <td>

                                <?= e($asset['status']) ?>

                            </td>

                        </tr>

                    </table>

                </div>

            </div>

            <!-- TEHNICKI PODACI -->

            <div class="card shadow-sm border-0 mb-4">

                <div class="card-header">

                    <h5 class="mb-0">

                        Tehnički podaci

                    </h5>

                </div>

                <div class="card-body">

                    <table class="table align-middle mb-0">

                        <tr>

                            <th width="240">

                                Proizvođač

                            </th>

                            <td>

                                <?= e($asset['manufacturer'] ?? '-') ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Model

                            </th>

                            <td>

                                <?= e($asset['model'] ?? '-') ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Serijski broj

                            </th>

                            <td>

                                <?= e($asset['serial_number'] ?? '-') ?>

                            </td>

                        </tr>

                    </table>

                </div>

            </div>

            <!-- DINAMICKI ATRIBUTI -->

            <div class="card shadow-sm border-0 mb-4">

                <div class="card-header">

                    <h5 class="mb-0">

                        Dinamički atributi

                    </h5>

                </div>

                <div class="card-body">

                    <?php if ($attributes->num_rows > 0): ?>

                        <div class="row">

                            <?php while ($attr = $attributes->fetch_assoc()): ?>

                                <div class="col-md-4 mb-3">

                                    <small class="text-muted d-block">

                                        <?= e($attr['name']) ?>

                                    </small>

                                    <div class="fw-semibold">

                                        <?= e($attr['value_text']) ?>

                                    </div>

                                </div>

                            <?php endwhile; ?>

                        </div>

                    <?php else: ?>

                        <div class="text-muted">

                            Nema definisanih atributa.

                        </div>

                    <?php endif; ?>

                </div>

            </div>

            <!-- FINANSIJE -->

            <div class="card shadow-sm border-0">

                <div class="card-header">

                    <h5 class="mb-0">

                        Finansije

                    </h5>

                </div>

                <div class="card-body">

                    <table class="table align-middle mb-0">

                        <tr>

                            <th width="240">

                                Datum kupovine

                            </th>

                            <td>

                                <?= e($asset['purchase_date'] ?? '-') ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Garancija do

                            </th>

                            <td>

                                <?= e($asset['warranty_until'] ?? '-') ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Dobavljač

                            </th>

                            <td>

                                <?= e($asset['supplier'] ?? '-') ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Cena

                            </th>

                            <td>

                                <?= e($asset['unit_price'] ?? '-') ?>

                            </td>

                        </tr>

                    </table>

                </div>

            </div>

        </div>

        <!-- RIGHT -->

        <div class="col-lg-4">

            <!-- ZADUZENJE -->

            <div class="card shadow-sm border-0 mb-4">

                <div class="card-header">

                    <h5 class="mb-0">

                        Trenutno zaduženje

                    </h5>

                </div>

                <div class="card-body">

                    <?php if ($currentAssignment): ?>

                        <div class="mb-3">

                            <small class="text-muted d-block">

                                Zaposleni

                            </small>

                            <div class="fw-semibold">

                                <?= e(
                                    $currentAssignment['first_name']
                                        . ' '
                                        . $currentAssignment['last_name']
                                ) ?>

                            </div>

                        </div>

                        <div class="mb-3">

                            <small class="text-muted d-block">

                                Matični broj

                            </small>

                            <div>

                                <?= e($currentAssignment['personal_id']) ?>

                            </div>

                        </div>

                        <div class="mb-3">

                            <small class="text-muted d-block">

                                Organizaciona jedinica

                            </small>

                            <div>

                                <?= e($currentAssignment['unit_name']) ?>

                            </div>

                        </div>

                        <div>

                            <small class="text-muted d-block">

                                Zadužen od

                            </small>

                            <div>

                                <?= e($currentAssignment['assigned_at']) ?>

                            </div>

                        </div>

                    <?php else: ?>

                        <div class="text-muted">

                            Inventar trenutno nije zadužen.

                        </div>

                    <?php endif; ?>

                </div>

                <!-- ISTORIJA ZADUZENJA -->

                <div class="card shadow-sm border-0 mb-4">

                    <div class="card-header">

                        <h5 class="mb-0">

                            Istorija zaduženja

                        </h5>

                    </div>

                    <div class="card-body">

                        <?php

                        $historyStmt = $conn->prepare("
            SELECT
                aa.assigned_at,
                aa.returned_at,
                aa.notes,

                e.first_name,
                e.last_name,
                e.personal_id

            FROM asset_assignments aa

            LEFT JOIN employees e
                ON e.id = aa.employee_id

            WHERE aa.asset_id = ?

            ORDER BY aa.assigned_at DESC
        ");

                        $historyStmt->bind_param(
                            "i",
                            $id
                        );

                        $historyStmt->execute();

                        $history =
                            $historyStmt->get_result();
                        ?>

                        <?php if ($history->num_rows > 0): ?>

                            <div class="table-responsive">

                                <table class="table table-sm align-middle">

                                    <thead>

                                        <tr>

                                            <th>Zaposleni</th>

                                            <th>Matični broj</th>

                                            <th>Od</th>

                                            <th>Do</th>

                                            <th>Status</th>

                                        </tr>

                                    </thead>

                                    <tbody>

                                        <?php while ($h = $history->fetch_assoc()): ?>

                                            <tr>

                                                <td>

                                                    <?= e(
                                                        $h['first_name']
                                                            . ' '
                                                            . $h['last_name']
                                                    ) ?>

                                                </td>

                                                <td>

                                                    <?= e($h['personal_id']) ?>

                                                </td>

                                                <td>

                                                    <?= e($h['assigned_at']) ?>

                                                </td>

                                                <td>

                                                    <?= e(
                                                        $h['returned_at']
                                                            ?? '-'
                                                    ) ?>

                                                </td>

                                                <td>

                                                    <?php if ($h['returned_at']): ?>

                                                        <span class="badge bg-secondary">

                                                            Razdužen

                                                        </span>

                                                    <?php else: ?>

                                                        <span class="badge bg-success">

                                                            Aktivno

                                                        </span>

                                                    <?php endif; ?>

                                                </td>

                                            </tr>

                                        <?php endwhile; ?>

                                    </tbody>

                                </table>

                            </div>

                        <?php else: ?>

                            <div class="text-muted">

                                Nema istorije zaduženja.

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </div>

    </div>

</main>

<!-- MODAL za izmenu inventara -->

<div
    class="modal fade"
    id="assetEditModal"
    tabindex="-1">

    <div class="modal-dialog modal-lg modal-dialog-scrollable">

        <div class="modal-content">

            <form
                method="POST"
                action="../actions/assets_update.php">

                <input
                    type="hidden"
                    name="id"
                    value="<?= $asset['id'] ?>">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= csrf_token() ?>">

                <div class="modal-header">

                    <h5 class="modal-title">

                        Izmena inventara

                    </h5>

                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                    </button>

                </div>

                <div class="modal-body">

                    <div class="row g-2">

                        <div class="col-md-6">

                            <label class="form-label">

                                Naziv

                            </label>

                            <input
                                type="text"
                                name="name"
                                class="form-control"
                                value="<?= e($asset['name']) ?>"
                                required>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">

                                Inventarski broj

                            </label>

                            <input
                                type="text"
                                name="inventory_number"
                                class="form-control"
                                value="<?= e($asset['inventory_number']) ?>"
                                required>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">

                                Proizvođač

                            </label>

                            <input
                                type="text"
                                name="manufacturer"
                                class="form-control"
                                value="<?= e($asset['manufacturer']) ?>">

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">

                                Model

                            </label>

                            <input
                                type="text"
                                name="model"
                                class="form-control"
                                value="<?= e($asset['model']) ?>">

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">

                                Serijski broj

                            </label>

                            <input
                                type="text"
                                name="serial_number"
                                class="form-control"
                                value="<?= e($asset['serial_number']) ?>">

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button
                        type="submit"
                        class="btn btn-primary">

                        Sačuvaj izmene

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<div
    class="modal fade"
    id="changeAssignmentModal"
    tabindex="-1">

    <div class="modal-dialog">

        <div class="modal-content">

            <form
                method="POST"
                action="../actions/assignment_change.php">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= csrf_token() ?>">

                <input
                    type="hidden"
                    name="assignment_id"
                    value="<?= $currentAssignment['id'] ?? '' ?>">

                <input
                    type="hidden"
                    name="asset_id"
                    value="<?= $asset['id'] ?>">

                <div class="modal-header">

                    <h5 class="modal-title">

                        Promena zaduženja

                    </h5>

                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"></button>

                </div>

                <div class="modal-body">

                    <label class="form-label">

                        Novi zaposleni

                    </label>

                    <select
                        name="employee_id"
                        class="form-select"
                        required>

                        <option value="">
                            Izaberi zaposlenog
                        </option>

                        <?php

                        $emps = $conn->query("
                            SELECT
                                id,
                                first_name,
                                last_name
                            FROM employees
                            ORDER BY first_name, last_name
                        ");

                        while ($emp = $emps->fetch_assoc()):
                        ?>

                            <option value="<?= $emp['id'] ?>">

                                <?= e(
                                    $emp['first_name']
                                        . ' '
                                        . $emp['last_name']
                                ) ?>

                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>

                <div class="modal-footer">

                    <button
                        type="submit"
                        class="btn btn-warning">

                        Promeni

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<?php include "../../../layouts/footer.php"; ?>