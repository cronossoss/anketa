<?php

require_once "../../../config/init.php";

require_login();

require_role(['admin', 'it']);

if (
    !verify_csrf(
        $_POST['csrf_token'] ?? ''
    )
) {

    die('CSRF greška.');
}

$assetTypeId =
    (int)($_POST['asset_type_id'] ?? 0);

$name = trim($_POST['name'] ?? '');

$code = trim($_POST['code'] ?? '');

$stmt = $conn->prepare("
    INSERT INTO asset_categories (
        asset_type_id,
        name,
        code
    )
    VALUES (?, ?, ?)
");

$stmt->bind_param(
    "iss",
    $assetTypeId,
    $name,
    $code
);

$stmt->execute();

header(
    "Location: ../categories/index.php"
);

exit;
