<?php

require_once ROOT_PATH . '/helpers/organization_tree.php';

require_once ROOT_PATH . '/helpers/manager_dashboard.php';

$managerEmployeeId =
    (int)$_SESSION['employee_id'];

$employeeCount =
    getManagedEmployeeCount(
        $conn,
        $managerEmployeeId
    );

$pendingAbsences =
    getPendingAbsenceCount(
        $conn,
        $managerEmployeeId
    );

$pendingExitPasses =
    getPendingExitPassCount(
        $conn,
        $managerEmployeeId
    );

$dangerAnnouncements =
    (int)$conn
        ->query("
            SELECT COUNT(*) total
            FROM announcements
            WHERE active = 1
              AND priority = 'danger'
        ")
        ->fetch_assoc()['total'];
$managedEmployees =
    getManagedEmployeeIds(
        $conn,
        $managerEmployeeId
    );

$pendingRequests = [];

if (!empty($managedEmployees)) {

    $employeeIds =
        implode(
            ',',
            array_map(
                'intval',
                $managedEmployees
            )
        );

    $sql = "

        SELECT
            a.id,
            'absence' AS request_type,
            e.first_name,
            e.last_name,
            t.name AS type_name,
            a.date_from,
            a.date_to,
            a.created_at

        FROM attendance_absences a

        INNER JOIN employees e
            ON e.id = a.employee_id

        INNER JOIN attendance_absence_types t
            ON t.id = a.absence_type_id

        WHERE a.status = 'pending'
          AND a.employee_id IN ($employeeIds)

        UNION ALL

        SELECT
            p.id,
            'exit' AS request_type,
            e.first_name,
            e.last_name,
            t.name AS type_name,
            p.date_from,
            p.date_to,
            p.created_at

        FROM attendance_exit_passes p

        INNER JOIN employees e
            ON e.id = p.employee_id

        INNER JOIN attendance_exit_types t
            ON t.id = p.exit_type_id

        WHERE p.status = 'pending'
          AND p.employee_id IN ($employeeIds)

        ORDER BY created_at DESC

        LIMIT 5
    ";

    $pendingRequests =
        $conn
        ->query($sql)
        ->fetch_all(MYSQLI_ASSOC);
}
?>

<div class="row g-3 mb-4">

    <div class="col-md-3">

        <div class="dashboard-card">

            <div class="dashboard-card-title">

                Zahtevi

            </div>

            <div class="dashboard-card-value">

                <?= $pendingAbsences + $pendingExitPasses ?>

            </div>

        </div>

    </div>

    <div class="col-md-3">

        <div class="dashboard-card">

            <div class="dashboard-card-title">

                Odsustva

            </div>

            <div class="dashboard-card-value">

                <?= $pendingAbsences ?>

            </div>

        </div>

    </div>

    <div class="col-md-3">

        <div class="dashboard-card">

            <div class="dashboard-card-title">

                Izlaznice

            </div>

            <div class="dashboard-card-value">

                <?= $pendingExitPasses ?>

            </div>

        </div>

    </div>

    <div class="col-md-3">

        <div class="dashboard-card">

            <div class="dashboard-card-title">

                Obaveštenja

            </div>

            <div class="dashboard-card-value">

                <?= $dangerAnnouncements ?>

            </div>

        </div>

    </div>

</div>

<div class="card shadow-sm mb-4">

    <div class="card-header">

        <strong>

            Moja organizaciona jedinica

        </strong>

    </div>

    <div class="card-body">

        <h4>

            <?= e($_SESSION['department_name'] ?? '') ?>

        </h4>

        <p class="mb-0">

            Broj zaposlenih:

            <strong>

                <?= $employeeCount ?>

            </strong>

        </p>

    </div>

</div>

<div class="card shadow-sm">

    <div class="card-header d-flex justify-content-between">

        <strong>
            Zahtevi za odobrenje
        </strong>

        <a href="<?= url('modules/attendance/approvals.php') ?>">
            Prikaži sve
        </a>

    </div>

    <div class="card-body p-0">

        <?php if (empty($pendingRequests)): ?>

            <div class="p-3 text-muted">

                Nema zahteva za odobrenje.

            </div>

        <?php else: ?>

            <div class="table-responsive">

                <table class="table mb-0">

                    <thead>

                        <tr>

                            <th>Zaposleni</th>

                            <th>Tip</th>

                            <th>Period</th>

                            <th>Podneto</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php foreach ($pendingRequests as $request): ?>

                            <tr>

                                <td>

                                    <?= e(
                                        $request['first_name']
                                            . ' '
                                            . $request['last_name']
                                    ) ?>

                                </td>

                                <td>

                                    <?= e(
                                        $request['type_name']
                                    ) ?>

                                </td>

                                <td>

                                    <?= e(
                                        date(
                                            'd.m.Y',
                                            strtotime(
                                                $request['date_from']
                                            )
                                        )
                                    ) ?>

                                    -

                                    <?= e(
                                        date(
                                            'd.m.Y',
                                            strtotime(
                                                $request['date_to']
                                            )
                                        )
                                    ) ?>

                                </td>

                                <td>

                                    <?= e(
                                        date(
                                            'd.m.Y H:i',
                                            strtotime(
                                                $request['created_at']
                                            )
                                        )
                                    ) ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </div>

</div>