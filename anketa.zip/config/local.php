<?php

define(
    'BASE_URL',
    'http://localhost/anketa/'
);

define('DB_HOST', 'localhost');
define('DB_NAME', 'dedamraz_anketa');

define('DB_USER', 'dedamraz_anketa');
define('DB_PASS', 'a9^g23KqPfZTd;0.');
