<?php

require_once '../../../config/init.php';

require_once '../../../vendor/autoload.php';

require_once dirname(__DIR__) . '/helpers/audit.php';

require_login();

require_role(['admin', 'it']);

$selectedRows =
    $_POST['selected_rows'] ?? [];

$importLimit =
    (int) ($_POST['import_limit'] ?? 100);

$importId =
    (int) ($_POST['import_id'] ?? 0);

if (!$importId) {

    die('Import nije pronađen.');
}

/* =========================
   IMPORT ROWS
========================= */

$ids =
    implode(
        ',',
        array_map(
            'intval',
            $selectedRows
        )
    );

if (!$ids) {

    die('Nema izabranih redova.');
}

$rowsResult = $conn->query("
    SELECT *
    FROM asset_import_rows
    WHERE id IN ({$ids})
    AND validation_status != 'error'
    ORDER BY row_number
    LIMIT {$importLimit}
");

$imported = 0;
$skipped = 0;
$failed = 0;

/* =========================
   PROCESS
========================= */

while ($row = $rowsResult->fetch_assoc()) {

    try {

        $inventoryNumber =
            trim($row['inventory_number']);

        if (!$inventoryNumber) {

            $failed++;

            continue;
        }

        /* =========================
           DUPLICATE CHECK
        ========================= */

        $inventoryEscaped =
            $conn->real_escape_string(
                $inventoryNumber
            );

        $existingResult =
            $conn->query("
                SELECT id
                FROM assets
                WHERE inventory_number = '{$inventoryEscaped}'
                LIMIT 1
            ");

        if ($existingResult->num_rows > 0) {

            $skipped++;

            $conn->query("
                UPDATE asset_import_rows
                SET validation_status = 'skipped'
                WHERE id = {$row['id']}
            ");

            continue;
        }

        /* =========================
           CATEGORY
        ========================= */

        $categoryName =
            trim($row['category_name']);

        $categoryId = null;
        $assetTypeId = null;

        if ($categoryName) {

            $categoryEscaped =
                $conn->real_escape_string(
                    $categoryName
                );

            $categoryResult =
                $conn->query("
                    SELECT
                        id,
                        asset_type_id
                    FROM asset_categories
                    WHERE name = '{$categoryEscaped}'
                    LIMIT 1
                ");

            if ($categoryResult->num_rows > 0) {

                $category =
                    $categoryResult
                    ->fetch_assoc();

                $categoryId =
                    (int) $category['id'];

                $assetTypeId =
                    (int) $category['asset_type_id'];
            }
        }

        /* =========================
           DEFAULT STATUS
        ========================= */

        $status = 'slobodno';

        if ($row['employee_id']) {

            $status = 'zaduzen';
        }

        /* =========================
           INSERT ASSET
        ========================= */

        $stmt = $conn->prepare("
            INSERT INTO assets (

                inventory_number,
                asset_type_id,
                category_id,

                manufacturer,
                model,
                serial_number,

                status

            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $manufacturer =
            trim($row['manufacturer']);

        $model =
            trim($row['model']);

        $serialNumber =
            trim($row['serial_number']);

        $stmt->bind_param(
            "siissss",

            $inventoryNumber,
            $assetTypeId,
            $categoryId,

            $manufacturer,
            $model,
            $serialNumber,

            $status
        );

        $stmt->execute();

        $assetId =
            $conn->insert_id;

        /* =========================
           ASSIGNMENT
        ========================= */

        if ($row['employee_id']) {

            $employeeId =
                (int) $row['employee_id'];

            $assignedBy =
                (int) $_SESSION['user_id'];

            $assignStmt = $conn->prepare("
                INSERT INTO asset_assignments (

                    asset_id,
                    employee_id,
                    assigned_by

                )
                VALUES (?, ?, ?)
            ");

            $assignStmt->bind_param(
                "iii",

                $assetId,
                $employeeId,
                $assignedBy
            );

            $assignStmt->execute();
        }

        /* =========================
           RAW DATA ATTRIBUTES
        ========================= */

        $rawData =
            json_decode(
                $row['raw_data'],
                true
            );

        if (is_array($rawData)) {

            foreach ($rawData as $key => $value) {

                $key =
                    trim((string)$key);

                $value =
                    trim((string)$value);

                if (!$key || !$value) {
                    continue;
                }

                /* =========================
                   ATTRIBUTE MAP
                ========================= */

                $attributeCode = match (
                    mb_strtolower($key)
                ) {

                    'cpu' => 'cpu',

                    'ram' => 'ram',

                    'gpu' => 'gpu',

                    'grafika' => 'gpu',

                    'os' => 'os',

                    'operativni sistem' => 'os',

                    'hdd' => 'storage',

                    'ssd' => 'storage',

                    'disk' => 'storage',

                    'antivirus' => 'antivirus',

                    default => null
                };

                if (!$attributeCode) {
                    continue;
                }

                /* =========================
                   FIND ATTRIBUTE
                ========================= */

                $attributeEscaped =
                    $conn->real_escape_string(
                        $attributeCode
                    );

                $attributeResult =
                    $conn->query("
                        SELECT id
                        FROM asset_attribute_definitions
                        WHERE code = '{$attributeEscaped}'
                        LIMIT 1
                    ");

                if ($attributeResult->num_rows < 1) {
                    continue;
                }

                $attribute =
                    $attributeResult
                    ->fetch_assoc();

                $attributeId =
                    (int) $attribute['id'];

                /* =========================
                   SAVE ATTRIBUTE
                ========================= */

                $stmtAttr = $conn->prepare("
                    INSERT INTO asset_attribute_values (

                        asset_id,
                        attribute_definition_id,
                        value_text

                    )
                    VALUES (?, ?, ?)
                ");

                $stmtAttr->bind_param(
                    "iis",

                    $assetId,
                    $attributeId,
                    $value
                );

                $stmtAttr->execute();
            }
        }

        /* =========================
           IMPORT STATUS
        ========================= */

        $conn->query("
            UPDATE asset_import_rows
            SET validation_status = 'imported'
            WHERE id = {$row['id']}
        ");

        /* =========================
           AUDIT
        ========================= */

        logAudit(
            $conn,
            $_SESSION['user_id'],
            'assets',
            'import',
            $assetId,
            'Importovan inventar: '
            . $inventoryNumber
        );

        $imported++;

    } catch (Exception $e) {

        $failed++;

        $messageEscaped =
            $conn->real_escape_string(
                $e->getMessage()
            );

        $conn->query("
            UPDATE asset_import_rows
            SET
                validation_status = 'error',
                validation_message = '{$messageEscaped}'
            WHERE id = {$row['id']}
        ");
    }
}

/* =========================
   FINALIZE IMPORT
========================= */

$conn->query("
    UPDATE asset_imports
    SET

        imported_rows = {$imported},
        skipped_rows = {$skipped},
        failed_rows = {$failed},

        status = 'completed',

        completed_at = NOW()

    WHERE id = {$importId}
");

/* =========================
   SUCCESS
========================= */

$_SESSION['success'] =
    'Import završen. '
    . 'Uvezeno: '
    . $imported
    . ', preskočeno: '
    . $skipped
    . ', greške: '
    . $failed;

header(
    "Location: preview.php?id={$importId}"
);

exit;